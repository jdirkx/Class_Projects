from hashmap import HashMap
from dynamicarray import DynamicArray
import sys
import getopt
import re

EXIT_SUCCESS = 0
EXIT_FAILURE = 1

def translate(line: 'one line address') -> 'translated line': 
    translations = {
    'St.':'Street',
    'Dr.':'Drive',
    'Rd.':'Road',
    'Ave.':'Avenue',
    'Pkwy.':'Parkway'
    }
    for abbr, full in translations.items():
        line = re.sub('{}'.format(re.escape(abbr)), full, line)
    return line

def extractSS(line: 'one line address') -> '2 letter state abbv':
    name, address, csz = line.strip().split('|')
    city, sz = csz.split(',')
    ss, zp = sz.rsplit(' ',1)
    return ss.strip()

def create_SSarray(SS: '2-letter state abbr', args: 'filenames', text: 'text', full_addrs: 'boolean for full/abbv') -> 'DynamicArray':
    state_array = DynamicArray(dtype = str)

    if args:
        for filename in args:
            with open(filename, 'r') as file:
                for line in file:
                    if extractSS(line) == SS:
                        if full_addrs:
                            line = translate(line)
                        state_array.add(line)
    elif text:
        for line in text:
            if extractSS(line) == SS:
                if full_addrs:
                    line = translate(line)
                state_array.add(line)

    if state_array.isEmpty():
        sys.stderr.write('USPSaddresses.py: no addresses found for {}'.format(SS))
        return None
    else:
        return state_array

def pop_hashmap(state_map: 'HashMap', line: 'address line', args: 'files', text: 'text', full_addrs: 'boolean for full/abbv') -> 'populated hashmap':
    SS = extractSS(line)
    if not state_map.containsKey(SS):
        if args:
            new_array = create_SSarray(SS, args, None, full_addrs)
            if new_array:
                state_map.put(SS, new_array)
        elif text:
            new_array = create_SSarray(SS, None, text, full_addrs)
            if new_array:
                state_map.put(SS, new_array)
    return state_map

def print_hashmap(state_map: 'HashMap', states: 'list of SS', three_line: 'boolean for 3 line printing') -> 'prints hashmap contents':
    if states:
        for SS in states:
            if state_map.containsKey(SS):
                for line in state_map.get(SS):
                    if three_line:
                        name, address, csz = line.strip().split('|')
                        sys.stdout.write('{}\n{}\n{}\n'.format(name, address, csz))
                    else:
                        sys.stdout.write('{}'.format(line))
            else:
                sys.stderr.write('USPSaddresses.py: SS {} not found\n'.format(SS))
                
    else:
        keys = sorted(state_map.keyArray())
        for SS in keys:
            for line in state_map.get(SS):
                if three_line:
                    name, address, csz = line.strip().split('|')
                    sys.stdout.write('{}\n{}\n{}\n'.format(name, address, csz))
                else:
                    sys.stdout.write('{}'.format(line))
                    

def main():
    try:
        opts, args = getopt.getopt(sys.argv[1:], "13xs:", [""])
    except getopt.GetoptError as err:
        sys.stderr.write('getopt error: ' + str(err) + ' in {}\n'
                         .format(sys.argv[0]))
        sys.exit(EXIT_FAILURE)

    three_line = True
    full_addrs = False
    states = None
    
    for opt, arg in opts:
        if opt == '-1':
            three_line = False
        elif opt == '-3':
            three_line = True
        elif opt == '-x':
            full_addrs = True
        elif opt == '-s':
            if arg:
                states = arg.split(',')
            else:
                sys.stderr.write('USPSaddresses.py: No SS provided\n')
                sys.exit(EXIT_FAILURE)
        elif opt not in ['-1', '-3', '-x', '-s']:
            sys.stderr.out('Invalid flag: {}\n'.format(opt))
            sys.exit(EXIT_FAILURE)

    
    state_map = HashMap(dtype = DynamicArray)

    if not args:
        text = sys.stdin.readlines()
        for line in text:
            state_map = pop_hashmap(state_map, line, None, text, full_addrs)
    else:
        for filename in args:
            try:
                with open(filename, 'r') as file:
                    for line in file:
                        state_map = pop_hashmap(state_map, line, args, None, full_addrs)
            except FileNotFoundError:
                sys.stderr.write('Unable to open file {}\n'.format(filename))
                sys.exit(EXIT_FAILURE)

    print_hashmap(state_map, states, three_line)
    
    sys.exit(EXIT_SUCCESS)
    


if __name__ == '__main__':
    main()
