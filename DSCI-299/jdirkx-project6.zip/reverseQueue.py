#!/usr/bin/python3
from arrayqueue import ArrayQueue
import sys

EXIT_SUCCESS = 0
EXIT_FAILURE = 1

def reverse(q: 'a queue'):
    
    rev_elems = []
    while not q.isEmpty():
        rev_elems.append(q.dequeue())
    
    while rev_elems:
        elem = rev_elems.pop()
        if rev_elems:
            sys.stdout.write('{} '.format(elem))
        else:
            sys.stdout.write('{}\n'.format(elem))


def main():

    try:
        file_path = sys.argv[1]
        file = open(file_path, 'r')
    except FileNotFoundError:
        sys.stderr.write('Error: file {} not found\n'.format(file))
        sys.exit(EXIT_FAILURE)

    with open(file_path, 'r') as file:
        n = int(file.readline().strip())
        for i in range(n):
            n_elems = int(file.readline().strip())
            q = ArrayQueue(n_elems)
            elems = file.readline().strip().split()
            for elem in elems:
                q.enqueue(int(elem))
            reverse(q)

    sys.exit(EXIT_SUCCESS)

if __name__ == '__main__':
    main()
