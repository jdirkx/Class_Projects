#!usr/bin/python3
from queueABC import QueueABC
import numpy as np
from ADTtypemap import typemap
from ADTexceptions import *
import ADTiterator as it

class LListQueue(QueueABC):
    """
    LList-based version of ArrayQueue ADT

    Attributes
    - _dtype - data type of queue elemenets, default is int()
    - _count - number of elements in llist
    - _head - first element/LListQueue.node of llist
    - _tail - last element/LListQueue.node of llist
    """
    class Node:
        """Singly-linked list node used for LListQueue"""
        def __init__(self, datum):
            """Constructor returning empty node linked to itself"""
            self._datum = datum
            self._next = None

    def __init__(self, dtype= type(int())):
        """
        Constructor for LListQueue

        Parameters
        - dtype (a class) - type of queue elements, default is int()

        Effects
        - object instance ready to act as Queue
        """
        self._dtype = typemap(dtype)
        self._count = 0
        self._head = None
        self._tail = None
        
    def __str__(self):
        """Document metadata about queue object"""
        return 'LListQueue - count: {}, dtype = {}'.format(
                self._count, self._dtype)

    def clear(self):
        """
        Empties queue

        Effects
        - after return, isEmpty() invoked on queue returns True
        """
        self._count = 0
        self._head = None
        self._tail = None

    def isEmpty(self):
        """
        Check if queue is empty

        Returns
        - True if queue count is 0
        """
        return self._count == 0

    def size(self):
        """
        Returns size of queue

        Returns
        - queue count
        """
        return self._count

    def enqueue(self, datum):
        """
        Enqueues item at tail of queue unless isEmpty returns True

        Parameters
        - datum - datum of correct type

        Effects
        - queue grows by one element

        Raises
        - TypeError is type of datum is not identical to _dtype
        """
        the_type = typemap(type(datum))
        if the_type != self._dtype:
            raise TypeError('LListQueue.enqueue - type(datum) {} != {}'.format(
                the_type, self._dtype))
        node = self.Node(datum)
        if self.isEmpty():
            self._head = node
        else:
            self._tail._next = node
        self._tail = node
        self._count += 1

    def front(self):
        """
        Returns element at head of queue

        Returns
        - element at head of queue

        Raises
        - EmptyError is queue is empty
        """
        if self.isEmpty():
            raise EmptyError('LListQueue.front - queue is empty')
        return self._head._datum

    def dequeue(self):
        """
        Removes and returns element at head of queue

        Returns
        - element at head of queue

        Effects
        - queue shrinks by one

        Raises
        - EmptyError is queue is empty
        """
        if self.isEmpty():
            raise EmptyError('LListQueue.front - queue is empty')
        node = self._head
        datum = node._datum
        self._head = node._next
        if self._head is None:
            self._tail = None
        self._count -= 1
        return datum

    def _genArray_(self):
        """
        Returns numpy 1D array with queue contents

        Returns
        - numpy 1D array with queue contents ordered head to tail

        Raises
        - MemoryError if unable to allocate memory
        """
        n = self._count
        try:
            x = np.empty(n, dtype = self._dtype)
        except:
            raise MemoryError('LListQueue._genArray_ - unable to allocate array')
        p = self._head
        j = 0
        while p!= None:
            x[j] = p._datum
            p = p._next
            j += 1
        return x

    def toArray(self):
        return self._genArray_()

    def itCreate(self):
        """
        Returns iterator over queue elements head to tail

        Returns
        - Iterator instance
        """
        n = self._count
        x = self._genArray_()
        return it.Iterator(n, x)
