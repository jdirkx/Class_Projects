import sys
import getopt
EXIT_SUCCESS = 0
EXIT_FAILURE = 1

def valid(filename):
    try:
        with open(filename, 'r'):
            pass
        return True
    except FileNotFoundError:
        sys.exit(EXIT_FAILURE)

def uniq(text, flags):

#list of lines, depending on if i is specified

    lines = text.readlines()
    if flags[2]:
        lowers = [line.lower() for line in lines]


#dict of frequencies of lines, lists of unique and duplicate lines

    counts = {}
    uniqlines = []
    duplines = []
    prev_line = None

#create frequency dict

    for line in lines:
        if line in counts:
            counts[line] += 1
        else:
            counts[line] = 1

#if i, use lowercase lines

    if flags[2]:
        zipped = list(zip(lines, lowers))
        for line, lower in zipped:
            if prev_line == lower and (not duplines or duplines[-1] != line):
                duplines.append(line)
            elif prev_line != lower and (not uniqlines or uniqlines[-1] != line):
                uniqlines.append(line)
            prev_line = lower
        if not any(flags[:2]):
            if not flags[3]:
                for line in uniqlines:
                    sys.stdout.write('{}\n'.format(line.strip()))

#else use regular lines

    else:
        for line in lines:
            if line == prev_line and (not duplines or duplines[-1] != line):
                duplines.append(line)
            elif line != prev_line and (not uniqlines or uniqlines[-1] != line):
                uniqlines.append(line)
            prev_line = line


#if no flags

    if not any(flags):
        for line in uniqlines:
            sys.stdout.write("{}\n".format(line.strip()))

#If c is specified

    if flags[0]:
        if flags[1]:
            for line, freq in counts.items():
                if line in duplines:
                    sys.stdout.write('{:>7} {}\n'.format(freq, line.strip()))
        elif flags[3]:
            for line, freq in counts.items():
                if line in uniqlines:
                    sys.stdout.write('{:>7} {}\n'.format(freq, line.strip()))
        else:
            for line, freq in counts.items():
                sys.stdout.write('{:>7} {}\n'.format(freq, line.strip()))
        
#If c is not specified

    elif not flags[0]:
        if flags[1] and not flags[3]:
            for line in duplines:
                sys.stdout.write('{}\n'.format(line.strip()))
        if flags[3] and not flags[1]:
            for line in uniqlines:
                sys.stdout.write('{}\n'.format(line.strip()))


def main():

    options = 'cdiu'
    flags = [False, False, False, False]

    try:
        opts, file = getopt.getopt(sys.argv[1:], options)
    except getopt.GetoptError as err:
        sys.stderr.write(str(err)+'\n')
        sys.exit(EXIT_FAILURE)

    if not opts:
        flags = [False, False, False, False]
    else:
        for o, a in opts:
            if o == '-c':
                flags[0] = True
            elif o == '-d':
                flags[1] = True
            elif o == '-i':
                flags[2] = True
            elif o == '-u':
                flags[3] = True
            else:
                sys.stderr.write("invalid option -- {}\n".format(opts))
                sys.exit(EXIT_FAILURE)

    if file and valid(file[0]):
        with open(file[0], 'r') as text:
            uniq(text, flags)
        
    else:
        text = sys.stdin
        uniq(text, flags)
    
    sys.exit(EXIT_SUCCESS)


if __name__ == "__main__":
    main()
