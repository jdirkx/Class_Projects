import numpy as np
import ADTiterator as it
from ADTexceptions import *
from ADTtypemap import typemap
from prioqueueABC import PrioQueueABC

class PrioQueueIntBounded(PrioQueueABC):
    """
    Singly linked list implementation of PrioQueue ADT

    Attributes
    - _dtype - type of data stored, default is int()
    - _size - number of (prio, datum) elements in the prio queue
    - _minP - minimum priority element in linked list
    - _maxP - maximum priority element in linked list
    """

    class Llist:
        """Singly linked list"""

        class Node:
            """Linked list node"""
            def __init__(self, prio, datum):
                self._next = None
                self._datum = datum
                self._prio = prio

        def __init__(self):
            self._size = 0
            self._head = None
            self._tail = None

        def isEmpty(self):
            return self._size == 0

        def append(self, prio, datum):
            new_node = PrioQueueIntBounded.Llist.Node(prio, datum)
            if self.isEmpty():
                self._head = new_node
                self._tail = new_node
            else:
                self._tail._next = new_node
                self._tail = new_node
            self._size += 1

    def __init__(self, minP: int, maxP: int, dtype = type(int())):
        self._dtype = typemap(dtype)
        self._size = 0
        self._minP = minP
        self._maxP = maxP
        self._queue = [PrioQueueIntBounded.Llist() for x in range(minP, maxP + 1)]

    def __str__(self):
        return 'PrioQueueIntBounded - size:{}, dtype:{}'.format(
                self._size, self._dtype)

    def clear(self):
        self._size = 0
        self._queue = [PrioQueueIntBounded.Llist() for x in range(minP, maxP + 1)]

    def insert(self, prio, datum):
        the_type = typemap(type(datum))
        if the_type != self._dtype:
            raise TypeError('PrioQueueIntBounded.insert - type(datum) {} != {}'
                            .format(the_type, self._dtype))
        if prio < self._minP or prio > self._maxP:
            raise ValueError('PrioQueueIntBounded.insert - prio {} out of range'
                             .format(prio))
        self._queue[prio - self._minP].append(prio, datum)
        self._size += 1

    def min(self):
        if not self.isEmpty():
            for llist in self._queue:
                if not llist.isEmpty():
                    node = llist._head
                    return (node._prio, node._datum)
        elif self.isEmpty():
            raise EmptyError('PrioQueueIntBounded.min - prio queue is empty')
            return None

    def removeMin(self):
        if not self.isEmpty():
            for llist in self._queue:
                if not llist.isEmpty():
                    node = llist._head
                    llist._head = node._next
                    llist._size -= 1
                    self._size -= 1
                    return (node._prio, node._datum)
        else:
            raise EmptyError('PrioQueueIntBounded.min - prio queue is empty')

    def isEmpty(self):
        return self._size == 0

    def size(self):
        return self._size

    def _genArray_(self):
        x = []
        for llist in self._queue:
            node = llist._head
            while node != None:
                x.append((node._prio, node._datum))
                node = node._next
        return x

    def toArray(self):
        return self._genArray_()

    def itCreate(self):
        n = self._size
        x = self._genArray_()
        return it.Iterator(n, x)


