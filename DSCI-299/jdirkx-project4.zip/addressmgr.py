import sys
import getopt
import time
from dynamicarray import DynamicArray
from accumulatordict import AccumulatorDict


EXIT_SUCCESS = 0
EXIT_FAILURE = 1
#USESTR = "python3 {} [-x] [-s SS] [FILE] ...\n"
FCT = AccumulatorDict()

def replace(line, abbrs, repls) -> str:
    text = line
    for j in range(len(abbrs)):
        text = text.replace(abbrs[j], repls[j])
    return text

def processOneFile(fd, ifX, ifS, state) -> int:
    pattern = ""
    abbrs = [ "St.", "Dr.", "Rd.", "Ave.", "Pkwy."]
    repls = [ "Street", "Drive", "Road", "Avenue", "Parkway"]
    if ifS:
        pattern = ' {} '.format(state)
    for line in fd:
        line = line.rstrip()
        if ifS and (pattern not in line):
            continue
        if ifX:
            start = time.time()*1000
            line = replace(line, abbrs, repls)
            stop = time.time()*1000
            FCT.increment('replace', (stop-start))
        lines = line.split('|')
        for line in lines:
            sys.stdout.write(line+'\n')
    return EXIT_SUCCESS

def processAllFiles(files, ifX: bool, ifS: bool, state: str) -> int:
    for fd in files:
        start = time.time()*1000
        processOneFile(fd, ifX, ifS, state)
        stop = time.time()*1000
        FCT.increment('processOneFile', (stop-start))
    return EXIT_SUCCESS;

def main() -> None:
    try:
        opts, args = getopt.getopt(sys.argv[1:], "xs:")
    except getopt.GetoptError as err:
        sys.stderr.write(str(err)+'\n')
        sys.stderr.write(USESTR.format(sys.argv[0]))
        sys.exit(EXIT_FAILURE)

    ifX = False
    ifS = False
    state = ''
    for o, a in opts:
        if o == '-x':
            ifX = True
        elif o == "-s":
            ifS = True
            state = a
    files = DynamicArray(1, type(sys.stdin))
    if len(args) == 0:
        files.add(sys.stdin)
    else:
        for f in args:
            try:
                fd = open(f, "r")
                files.add(fd)
            except:
                sys.stderr.write('Unable to open {}\n'.format(f))
                sys.exit(EXIT_FAILURE)
    start = time.time()*1000
    exit_status = processAllFiles(files, ifX, ifS, state)
    stop = time.time()*1000
    FCT.increment('processAllFiles', (stop-start))

    for x in FCT:
        sys.stderr.write('{},{},{}\n'.format(x[0], x[1], x[2]))

    sys.exit(exit_status)

if __name__ == "__main__":
    main()
