from arraystack import ArrayStack
import sys

EXIT_SUCCESS = 0
EXIT_FAILURE = 1


def evaluate(n: 'length of file', fp: 'file', st: 'ArrayStack') -> 'prints top of stack/solution':

    operators = {'+': lambda x, y: x+y,
                 '-': lambda x, y: x-y,
                 '*': lambda x, y: x*y,
                 '/': lambda x, y: x//y}

    for i in range(n):
        for item in fp.readline().split():
            if item.isdigit():
                st.push(int(item))
            elif item in operators:
                if len(st) < 2:
                    raise ValueError('Invalid expression')
                    sys.exit(EXIT_FAILURE)
                operandy = st.pop()
                operandx = st.pop()
                st.push(operators[item](operandx, operandy))
            else:
                raise ValueError('Invalid token: {}'.format(item))
                sys.exit(EXIT_FAILURE)
        sys.stdout.write('{}\n'.format(str(st.toArray()[0])))
        st.clear()

def main():
    try:
        with open(sys.argv[1], 'r') as file:
            n = int(file.readline().strip())
    except FileNotFoundError:
        st.stderr.write('File not found\n')
        sys.exit(EXIT_FAILURE)
    except:
        sys.stderr.write('Error when determining length of file\n')
        sys.exit(EXIT_FAILURE)

    st = ArrayStack()
    with open(sys.argv[1], 'r') as file:
        next(file)
        evaluate(n, file, st)
    sys.exit(EXIT_SUCCESS)

if __name__ == '__main__':
    main()
