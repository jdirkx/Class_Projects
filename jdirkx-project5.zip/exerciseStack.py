from arraystack import ArrayStack
import sys

EXIT_SUCCESS = 0
EXIT_FAILURE = 1

def printStack(st: 'ArrayStack') -> 'prints contents of stack': 
    if st.isEmpty():
        sys.stdout.write('Empty\n')
        return
    else:
        stack = st.toArray()

    for i, v in enumerate(stack):
        sys.stdout.write('{}'.format(v))
        if i < len(stack)-1:
            sys.stdout.write(' ')

    sys.stdout.write('\n')

def exerciseStack(n: 'length of file', fp: 'file', st: 'ArrayStack'):

    for i in range(n):
        line = fp.readline().rstrip()
        if 'push' in line:
            try:
                x = int(line.split()[1])
                st.push(x)
            except ValueError:
                sys.stderr.write('Invalid integer after push\n')
                sys.exit(EXIT_FAILURE)
        elif line == 'pop':
            if st.isEmpty():
                sys.stdout.write('StackError\n')
            else:
                sys.stdout.write('{}\n'.format(st.peek()))
                st.pop()
        elif line == 'print':
            printStack(st)

def main():
    try:
        with open(sys.argv[1], 'r') as file:
            n = int(file.readline().strip())
    except FileNotFoundError:
        sys.stderr.write('File not found\n')
        sys.exit(EXIT_FAILURE)
    except:
        sys.stderr.write('Error when determining length of file\n')
        sys.exit(EXIT_FAILURE)

    st = ArrayStack()
    with open(sys.argv[1], 'r') as file:
        next(file)
        exerciseStack(n, file, st)
    sys.exit(EXIT_SUCCESS)

if __name__ == '__main__':
    main()
